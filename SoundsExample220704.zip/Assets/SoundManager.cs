using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    private Dictionary<string, AudioClip> soundList = new Dictionary<string, AudioClip>();

    private GameObject audioPlayer;

    private void Awake()
    {
        AudioClip[] sounds = Resources.LoadAll<AudioClip>("Sounds");
        for (int i = 0; i < sounds.Length; i++)
        {
            soundList.Add(sounds[i].name, sounds[i]);
        }

        audioPlayer = Resources.Load<GameObject>("Prefabs/AudioPlayer");

        EventManager.AddEvent("Sound :: Create", (p) =>
        {
            CreateSound((string)p[0]);
        });

    }

    private void CreateSound(string clip)
    {
        GameObject go = Instantiate(audioPlayer);
        go.GetComponent<SoundPlayer>().Play(soundList[clip]);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundPlayer : MonoBehaviour
{
    private AudioSource player;

    private void Awake()
    {
        
    }

    public void Play(AudioClip clip)
    {
        player = GetComponent<AudioSource>();
        player.clip = clip;
        player.loop = false;
        player.Play();

        StartCoroutine(EndPlayer());
    }

    private IEnumerator EndPlayer()
    {
        yield return new WaitUntil(() => !player.isPlaying);
        Destroy(gameObject);
    }
}
